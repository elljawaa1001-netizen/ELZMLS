package com.elzmls.study

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                ELZMLSHome(
                    onEnableFloating = {
                        if (Settings.canDrawOverlays(this)) {
                            startService(Intent(this, FloatingPanelService::class.java))
                        } else {
                            startActivity(Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            ))
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ELZMLSHome(onEnableFloating: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("ELZMLS", style = MaterialTheme.typography.titleLarge)
                        Text("SMART STUDY ASSISTANT", style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.School, null) }, label = { Text("Beranda") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Calculate, null) }, label = { Text("Kalkulator") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Translate, null) }, label = { Text("Bahasa") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.PictureInPictureAlt, null) }, label = { Text("AI Tutor") })
            }
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(Modifier.padding(padding), onEnableFloating)
            1 -> CalculatorScreen(Modifier.padding(padding))
            2 -> TranslatorScreen(Modifier.padding(padding))
            else -> TutorScreen(Modifier.padding(padding))
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier, onEnableFloating: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Belajar lebih cerdas.", style = MaterialTheme.typography.headlineMedium)
        Text("Alat belajar dalam satu aplikasi. Gunakan AI Tutor untuk memahami materi dan latihan.")
        Card {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Floating Study Panel", style = MaterialTheme.typography.titleMedium)
                Text("Panel kecil ELZMLS yang terlihat jelas dan dapat ditutup kapan saja.")
                Button(onClick = onEnableFloating, modifier = Modifier.fillMaxWidth()) {
                    Text("Aktifkan floating panel")
                }
            }
        }
        FeatureCard("Kalkulator", "Hitung operasi dasar dan persentase.")
        FeatureCard("Penerjemah", "Terjemahkan teks untuk belajar bahasa.")
        FeatureCard("AI Tutor", "Minta penjelasan konsep dan latihan bertahap.")
        Text("ELZMLS tidak mengubah aplikasi ujian atau menyamarkan aktivitas.")
    }
}

@Composable
fun FeatureCard(title: String, description: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun CalculatorScreen(modifier: Modifier = Modifier) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Kalkulator", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(expression, { expression = it }, label = { Text("Contoh: (12+8)*3") },
            modifier = Modifier.fillMaxWidth())
        Button(onClick = { result = safeCalculate(expression) }, modifier = Modifier.fillMaxWidth()) {
            Text("Hitung")
        }
        Text("Hasil: $result", style = MaterialTheme.typography.titleLarge)
        Text("Mendukung angka, +, -, *, /, tanda kurung, dan desimal.")
    }
}

private fun safeCalculate(input: String): String {
    return try {
        val parser = ArithmeticParser(input)
        val value = parser.parse()
        if (value.isFinite()) value.toString() else "Hasil tidak valid"
    } catch (_: Exception) { "Periksa kembali rumus" }
}

private class ArithmeticParser(private val s: String) {
    private var p = 0
    fun parse(): Double {
        val v = expr()
        skip()
        require(p == s.length)
        return v
    }
    private fun skip() { while (p < s.length && s[p].isWhitespace()) p++ }
    private fun expr(): Double {
        var x = term()
        while (true) {
            skip()
            if (p < s.length && s[p] == '+') { p++; x += term() }
            else if (p < s.length && s[p] == '-') { p++; x -= term() }
            else return x
        }
    }
    private fun term(): Double {
        var x = factor()
        while (true) {
            skip()
            if (p < s.length && s[p] == '*') { p++; x *= factor() }
            else if (p < s.length && s[p] == '/') { p++; x /= factor() }
            else return x
        }
    }
    private fun factor(): Double {
        skip()
        if (p < s.length && s[p] == '+') { p++; return factor() }
        if (p < s.length && s[p] == '-') { p++; return -factor() }
        if (p < s.length && s[p] == '(') {
            p++; val x = expr(); skip(); require(p < s.length && s[p] == ')'); p++; return x
        }
        val start = p
        while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
        require(p > start)
        return s.substring(start, p).toDouble()
    }
}

@Composable
fun TranslatorScreen(modifier: Modifier = Modifier) {
    var source by remember { mutableStateOf("") }
    var translated by remember { mutableStateOf("") }
    var from by remember { mutableStateOf("en") }
    var to by remember { mutableStateOf("id") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Penerjemah online", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(source, { source = it }, label = { Text("Teks") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(from, { from = it }, label = { Text("Dari (kode)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(to, { to = it }, label = { Text("Ke (kode)") }, modifier = Modifier.weight(1f))
        }
        Button(enabled = !busy && source.isNotBlank(), onClick = {
            scope.launch {
                busy = true
                translated = runCatching { OnlineServices.translate(source, from, to) }
                    .getOrElse { "Terjemahan gagal: ${it.message ?: "periksa koneksi"}" }
                busy = false
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Menerjemahkan..." else "Terjemahkan") }
        Text(translated)
        Text("Contoh kode bahasa: en, id, es, ja, fr. Memerlukan internet.")
    }
}

@Composable
fun TutorScreen(modifier: Modifier = Modifier) {
    var baseUrl by remember { mutableStateOf("https://api.openai.com/v1") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gpt-4o-mini") }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("AI Tutor", style = MaterialTheme.typography.headlineMedium)
        Text("Tanyakan konsep, minta contoh, atau bahas soal latihan.")
        OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("API base URL") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(model, { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key (hanya di memori sesi)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(question, { question = it }, label = { Text("Pertanyaan belajar") },
            modifier = Modifier.fillMaxWidth(), minLines = 3)
        Button(enabled = !busy && question.isNotBlank() && apiKey.isNotBlank(),
            onClick = {
                scope.launch {
                    busy = true
                    answer = runCatching { OnlineServices.askTutor(baseUrl, apiKey, model, question) }
                        .getOrElse { "Permintaan gagal: ${it.message ?: "periksa konfigurasi"}" }
                    busy = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Memproses..." else "Tanya AI Tutor") }
        if (answer.isNotBlank()) Card { Text(answer, Modifier.padding(16.dp)) }
        Text("Jangan bagikan API key. Untuk rilis publik, gunakan backend milik sendiri.")
    }
}
