package com.elzmls.study

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object OnlineServices {
    private val client = OkHttpClient.Builder()
        .callTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun translate(text: String, from: String, to: String): String = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode(text, "UTF-8")
        val url = "https://api.mymemory.translated.net/get?q=$q&langpair=${from.trim()}|${to.trim()}"
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "HTTP ${response.code}" }
            val json = JSONObject(response.body?.string().orEmpty())
            json.getJSONObject("responseData").getString("translatedText")
        }
    }

    suspend fun askTutor(baseUrl: String, apiKey: String, model: String, question: String): String =
        withContext(Dispatchers.IO) {
            val endpoint = baseUrl.trimEnd('/') + "/chat/completions"
            val payload = JSONObject().apply {
                put("model", model)
                put("messages", org.json.JSONArray().put(
                    JSONObject().put("role", "system").put("content",
                        "You are ELZMLS, a patient study tutor. Explain concepts clearly, show steps, and encourage learning. For active tests or exams, provide conceptual guidance rather than covert answer delivery.")
                ).put(JSONObject().put("role", "user").put("content", question)))
            }
            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder().url(endpoint)
                .header("Authorization", "Bearer $apiKey")
                .post(body).build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                check(response.isSuccessful) { "HTTP ${response.code}: ${raw.take(300)}" }
                JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content")
            }
        }
}
