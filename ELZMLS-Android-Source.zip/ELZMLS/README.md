# ELZMLS — Android Study Assistant

Starter project for an Android learning app with:
- Calculator
- Online translation (MyMemory public endpoint; subject to its usage limits)
- AI Tutor using a user-configured OpenAI-compatible chat-completions endpoint
- User-enabled floating study panel (Android overlay permission)
- No exam-browser interference, stealth mode, tracking evasion, or hidden overlays

## Build
1. Open this folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Requires JDK 17 and Android SDK 35.

## AI Tutor setup
In the app, enter an OpenAI-compatible API base URL and API key, plus a model name.
Example base URL: `https://api.openai.com/v1`
The app sends prompts to `/chat/completions`.
Use an API key you control. For a production app, route requests through your own backend;
do not ship a permanent API key inside an APK.

## Floating panel
Tap "Enable floating panel". Android will ask you to grant "Display over other apps".
The panel is visible, clearly labeled ELZMLS, and can be closed with its X button.
It is not designed to cover exam interfaces or bypass exam restrictions.

## Notes
This is a source-code starter, not a prebuilt signed APK. A signed release APK requires
your own signing key and a build in Android Studio.
